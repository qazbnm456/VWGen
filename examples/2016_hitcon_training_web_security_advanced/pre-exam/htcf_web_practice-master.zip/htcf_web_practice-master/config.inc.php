<?php

	$DBMS = 'MySQL';
	$_HTCF = array();
	$_HTCF[ 'db_server' ]   = 'mysql';
	$_HTCF[ 'db_database' ] = 'root_mysql';
	$_HTCF[ 'db_user' ]     = 'root';
	$_HTCF[ 'db_password' ] = 'root_password';

	$db;

?>
