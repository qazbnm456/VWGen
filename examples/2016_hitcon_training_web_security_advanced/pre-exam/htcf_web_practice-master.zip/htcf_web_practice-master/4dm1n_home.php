<div class="figure">
    <img src="images/mario.png" width="200" height="200" alt="Pixel Mario">
</div>
<div class="article">
    <h2>Welcome to PixelShop 4dm1n Panel!</h2>
    <p>
        Not implemented yet...
    </p>
</div>