<?php
	$flag = "FLAG{wh47_d035_7h3_f0x_54y?}";
?>
